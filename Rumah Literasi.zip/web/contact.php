<?php
// Menampilkan error untuk debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require 'config.php';  // Pastikan koneksi ke database sudah benar

    // Ambil data dari form
    $name = $_POST['name'];
    $email = $_POST['email'];
    $message = $_POST['message'];

    // Cek apakah data sudah diterima dengan benar
    if (empty($name) || empty($email) || empty($message)) {
        echo "Semua field harus diisi!";
    } else {
        // Query untuk memasukkan data ke dalam database
        $stmt = $pdo->prepare("INSERT INTO messages (name, email, message) VALUES (?, ?, ?)");
        if ($stmt->execute([$name, $email, $message])) {
            echo "Pesan berhasil dikirim.";
        } else {
            echo "Error: Tidak bisa mengirim pesan.";
        }
    }
}
?>
