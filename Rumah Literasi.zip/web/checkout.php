<?php
session_start(); // Mulai session

// Menghapus keranjang setelah proses checkout
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    unset($_SESSION['keranjang']); // Menghapus data keranjang
}

?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pembayaran Berhasil</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f9;
            color: #333;
        }

        .success-container {
            width: 100%;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
            background-color: rgba(0, 123, 255, 0.3); /* Biru transparan */
        }

        h1 {
            color: #007BFF; /* Biru */
            font-size: 3em;
            margin-bottom: 20px;
            animation: fadeIn 2s ease-in-out;
        }

        .message {
            font-size: 1.5em;
            color: #007BFF;
            animation: fadeIn 2s ease-in-out 1s;
        }

        .image {
            margin-top: 20px;
            animation: fadeIn 2s ease-in-out 2s;
        }

        .back-btn {
            margin-top: 20px;
            background-color: #28a745; /* Hijau */
            color: white;
            padding: 10px 20px;
            text-align: center;
            text-decoration: none;
            border-radius: 5px;
            display: inline-block;
            transition: background-color 0.3s ease;
        }

        .back-btn:hover {
            background-color: #218838; /* Hijau lebih gelap */
        }

        @keyframes fadeIn {
            0% {
                opacity: 0;
                transform: translateY(30px);
            }
            100% {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .image img {
            width: 150px;
            height: auto;
        }
    </style>
</head>
<body>

    <div class="success-container">
        <h1>Pembayaran Berhasil!</h1>
        <p class="message">Happy Shopping!</p>
        <div class="image">
            <img src="pat
