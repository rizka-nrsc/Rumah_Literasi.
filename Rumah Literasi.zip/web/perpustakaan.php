<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit;
}

// Proses logout
if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: login.php");
    exit;
}

$host = "localhost";  
$username = "root";   
$password = "";       
$dbname = "rumah literasi"; 

$conn = new mysqli($host, $username, $password, $dbname);

// Cek koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Menyimpan transaksi ke database
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id_buku = $_POST['id_buku'];
    $jumlah = $_POST['jumlah'];

    // Ambil harga buku dari database
    $query = "SELECT harga FROM buku WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $id_buku);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    $harga = $row['harga'];

    // Hitung total harga
    $total_harga = $harga * $jumlah;

    // Masukkan transaksi ke tabel transaksi
    $tanggal = date("Y-m-d");
    $query_insert = "INSERT INTO transaksi (id_buku, jumlah, total_harga, tanggal) VALUES (?, ?, ?, ?)";
    $stmt_insert = $conn->prepare($query_insert);
    $stmt_insert->bind_param("iiis", $id_buku, $jumlah, $total_harga, $tanggal);
    $stmt_insert->execute();

    echo "Transaksi berhasil!";
}

// Ambil data buku untuk ditampilkan di form
$query_buku = "SELECT * FROM buku";
$result_buku = $conn->query($query_buku);

// Menyimpan transaksi ke database dan ke keranjang
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id_buku = $_POST['id_buku'];
    $jumlah = $_POST['jumlah'];

    // Ambil harga buku dari database
    $query = "SELECT judul, harga FROM buku WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $id_buku);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    
    $judul = $row['judul'];
    $harga = $row['harga'];
    
    // Hitung total harga
    $total_harga = $harga * $jumlah;

    // Simpan data ke session (keranjang)
    $_SESSION['keranjang'][] = [
        'id_buku' => $id_buku,
        'judul' => $judul,
        'jumlah' => $jumlah,
        'harga' => $harga,
        'total_harga' => $total_harga
    ];

    header('Location: keranjang.php'); // Arahkan ke halaman keranjang setelah beli
    exit;
}

// Ambil data buku untuk ditampilkan di form
$query_buku = "SELECT * FROM buku";
$result_buku = $conn->query($query_buku);
?>


<!DOCTYPE html>
<html lang="id">
<>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rumah Literasi</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #6a11cb 0%, #2575fc 100%);
            color: #fff;
            font-family: Arial, sans-serif;
        }

        .jumbotron {
            background: rgba(255, 255, 255, 0.1);
            padding: 2rem;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
        }

        .book-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 20px;
        }

        .book-card {
            background: #fff;
            color: #000;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            text-align: center;
            transition: transform 0.3s;
        }

        .book-card:hover {
            transform: scale(1.05);
        }

        .book-image {
            height: 200px;
            background-size: cover;
            background-position: center;
        }

        .reading-area {
            margin-top: 30px;
            padding: 20px;
            background-color: rgba(255, 255, 255, 0.1);
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
        }

        .reading-content img {
            width: 100px;
            display: block;
            margin: 0 auto 10px;
        }

        .reading-content h3 {
            text-align: center;
            margin-bottom: 20px;
        }

        .modal-content {
            border-radius: 10px;
        }

        .navbar {
            margin-bottom: 20px;
            background: rgba(255, 255, 255, 0.2);
            backdrop-filter: blur(10px);
        }

        .navbar-brand {
            color: #fff !important;
        }

        .logout-btn {
            position: absolute;
            top: 15px;
            right: 15px;
        }
    </style>
</head>

<body>
    <div class="container">
        <a href="?logout=true" class="btn btn-danger logout-btn">Logout</a>
        <div class="jumbotron text-center mb-4">
            <h1 class="animate-title">Selamat Datang di Rumah Literasi</h1>
            <p class="animate-description">Temukan inspirasi dan perluas wawasanmu dengan koleksi buku terbaik kami.</p>
        </div>
        <div class="row row-cols-1 row-cols-md-4 g-4">
            <div class="col">
                <div class="book-card">
                    <div class="book-image" style="background-image: url('img/1.jpeg');"></div>
                    <div class="book-info">
                        <h5>Statiska dasar untuk ilmu psikologi</h5>
                        <button class="btn btn-success btn-sm">Rp. 25.000</button>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="book-card">
                    <div class="book-image" style="background-image: url('img/2.jpeg');"></div>
                    <div class="psikologi">
                        <h5>Bicara itu ada seninya</h5>
                        <button class="btn btn-success btn-sm">Rp. 30.000</button>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="book-card">
                    <div class="book-image" style="background-image: url('img/3.jpeg');"></div>
                    <div class="psikologi">
                        <h5>Salah Itu Keren</h5>
                        <button class="btn btn-success btn-sm">Rp. 45.000</button>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="book-card">
                    <div class="book-image" style="background-image: url('img/4.jpeg');"></div>
                    <div class="book-info">
                        <h5>Diary Introvert</h5>
                        <button class="btn btn-success btn-sm">Rp. 45.000</button>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="book-card">
                    <div class="book-image" style="background-image: url('img/5.jpeg');"></div>
                    <div class="novel">
                        <h5>Mencari Teman dan Mempengaruhi Orang Lain</h5>
                        <button class="btn btn-success btn-sm">Rp. 50.000</button>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="book-card">
                    <div class="book-image" style="background-image: url('img/6.jpeg');"></div>
                    <div class="book-info">
                        <h5>Kau Sedang Terbentuk</h5>
                        <button class="btn btn-success btn-sm">Rp. 50.000</button>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="book-card">
                    <div class="book-image" style="background-image: url('img/7.jpeg');"></div>
                    <div class="buku">
                        <h5>Juara Mengatur Waktu</h5>
                        <button class="btn btn-success btn-sm">Rp. 25.000</button>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="book-card">
                    <div class="book-image" style="background-image: url('img/8.jpeg');"></div>
                    <div class="book-info">
                        <h5>Sesekali kita butuh sepi</h5>
                        <button class="btn btn-success btn-sm">Rp. 30.000</button>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="book-card">
                    <div class="book-image" style="background-image: url('img/9.jpeg');"></div>
                    <div class="book-info">
                        <h5>Banyak yang nggak betah jadi manusia</h5>
                        <button class="btn btn-success btn-sm">Rp. 35.000</button>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="book-card">
                    <div class="book-image" style="background-image: url('img/10.jpeg');"></div>
                    <div class="book-info">
                        <h5>Pendidikan Karakter-Sadar Allah</h5>
                        <button class="btn btn-success btn-sm">Rp. 25.000</button>
                    </div>
                </div>
            </div>

            <div class="col">
                <div class="book-card">
                    <div class="book-image" style="background-image: url('img/11.jpeg');"></div>
                    <div class="book-info">
                        <h5>Berdamai dengan diri sendiri</h5>
                        <button class="btn btn-success btn-sm">Rp. 45.000</button>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="book-card">
                    <div class="book-image" style="background-image: url('img/12.jpeg');"></div>
                    <div class="book-info">
                        <h5>Bumi Manusia</h5>
                        <button class="btn btn-success btn-sm">Rp. 30.000</button>
                    </div>
                </div>
            </div> <div class="col">
                <div class="book-card">
                    <div class="book-image" style="background-image: url('img/13.jpeg');"></div>
                    <div class="book-info">
                        <h5>Membentuk konsep diri melalui budaya tutur</h5>
                        <button class="btn btn-success btn-sm">Rp. 30.000</button>
                    </div>
                </div>
            </div> <div class="col">
                <div class="book-card">
                    <div class="book-image" style="background-image: url('img/14.jpeg');"></div>
                    <div class="book-info">
                        <h5>Setiap Luka akan pulih</h5>
                        <button class="btn btn-success btn-sm">Rp. 60.000</button>
                    </div>
                </div>
            </div> <div class="col">
                <div class="book-card">
                    <div class="book-image" style="background-image: url('img/15.jpeg');"></div>
                    <div class="book-info">
                        <h5>Percaya diri dan harga diri</h5>
                        <button class="btn btn-success btn-sm">Rp. 55.000</button>
                    </div>
                </div>
            </div> <div class="col">
                <div class="book-card">
                    <div class="book-image" style="background-image: url('img/16.jpeg');"></div>
                    <div class="book-info">
                        <h5>Cacat Logika</h5>
                        <button class="btn btn-success btn-sm">Rp. 75.000</button>
                    </div>
                </div>
            </div> <div class="col">
                <div class="book-card">
                    <div class="book-image" style="background-image: url('img/17.jpeg');"></div>
                    <div class="book-info">
                        <h5>Manusia Tanpa Sekolah</h5>
                        <button class="btn btn-success btn-sm">Rp. 45.000</button>
                    </div>
                </div>
            </div> <div class="col">
                <div class="book-card">
                    <div class="book-image" style="background-image: url('img/18.jpeg');"></div>
                    <div class="book-info">
                        <h5>Dipersulit oleh pikiran sendiri</h5>
                        <button class="btn btn-success btn-sm">Rp. 35.000</button>
                    </div>
                </div>
            </div> <div class="col">
                <div class="book-card">
                    <div class="book-image" style="background-image: url('img/19.jpeg');"></div>
                    <div class="book-info">
                        <h5>Kamu Hanya Perlu Pulang</h5>
                        <button class="btn btn-success btn-sm">Rp. 60.000</button>
                    </div>
                </div>
            </div> <div class="col">
                <div class="book-card">
                    <div class="book-image" style="background-image: url('img/20.jpeg');"></div>
                    <div class="book-info">
                        <h5>Quiet</h5>
                        <button class="btn btn-success btn-sm">Rp. 75.000</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container" style="margin-top: 100px; display: flex; flex-direction: column; align-items: center; justify-content: center; background-color: #fff; padding: 30px; border-radius: 10px; box-shadow: 0 6px 10px rgba(0, 0, 0, 0.1); width: 100%; max-width: 450px; text-align: center;">
    <h1 style="font-size: 1.8em; margin-bottom: 25px; color: #333;">Form Pembelian Buku</h1>

    <form action="perpustakaan.php" method="POST" style="display: flex; flex-direction: column; gap: 20px;">
        <label for="id_buku" style="font-size: 1.2em; margin-bottom: 8px; color: #555;">Pilih Buku</label>
        <select name="id_buku" id="id_buku" required style="padding: 14px; font-size: 1.1em; border-radius: 8px; border: 1px solid #ddd; width: 100%; box-sizing: border-box;">
            <?php
                // Koneksi ke database
                include 'koneksi.php'; // Sesuaikan dengan file koneksi kamu

                // Ambil data buku dari database
                $query = "SELECT id, judul FROM buku"; // Sesuaikan dengan nama tabel dan kolom kamu
                $result = mysqli_query($conn, $query);

                // Loop untuk menampilkan opsi buku dari database
                while ($row = mysqli_fetch_assoc($result)) {
                    echo "<option value='" . $row['id'] . "'>" . $row['judul'] . "</option>";
                }
            ?>
        </select>

        <label for="jumlah" style="font-size: 1.2em; margin-bottom: 8px; color: #555;">Jumlah Buku</label>
        <input type="number" id="jumlah" name="jumlah" min="1" required style="padding: 14px; font-size: 1.1em; border-radius: 8px; border: 1px solid #ddd; width: 100%; box-sizing: border-box;">

        <button type="submit" style="padding: 14px; font-size: 1.2em; background-color:rgb(4, 34, 68); color: white; border: none; border-radius: 8px; cursor: pointer; transition: background-color 0.3s ease;">Tambahkan ke Keranjang</button>
    </form>

    <div class="back-link" style="margin-top: 20px;">
    </div>
</div>

</div>



    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>

    
</body>
</html>
