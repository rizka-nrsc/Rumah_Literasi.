<?php
session_start();
include 'koneksi.php'; // Pastikan path-nya benar

// Cek apakah user_id ada di session
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php"); // Redirect ke halaman login jika belum login
    exit;
}

$user_id = $_SESSION['user_id'];

// Ambil data riwayat pembelian dari database
$sql = "SELECT * FROM riwayat_pembelian WHERE user_id = '$user_id' ORDER BY tanggal_pembelian DESC";
$result = mysqli_query($koneksi, $sql);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Riwayat Pembelian</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
        }
        .container {
            width: 80%;
            margin: 20px auto;
            background: #fff;
            border-radius: 8px;
            padding: 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        h1 {
            text-align: center;
            color: #4CAF50;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }
        table th, table td {
            padding: 10px;
            text-align: left;
            border: 1px solid #ddd;
        }
        table th {
            background: #4CAF50;
            color: #fff;
        }
        table tr:nth-child(even) {
            background: #f9f9f9;
        }
        .back-btn {
            display: block;
            width: 200px;
            margin: 20px auto;
            text-align: center;
            padding: 10px;
            background: #4CAF50;
            color: white;
            border-radius: 5px;
            text-decoration: none;
        }
        .back-btn:hover {
            background: #45a049;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Riwayat Pembelian</h1>
        <?php if (mysqli_num_rows($result) > 0): ?>
            <table>
                <thead>
                    <tr>
                        <th>Judul Buku</th>
                        <th>Jumlah</th>
                        <th>Harga per Buku</th>
                        <th>Total Harga</th>
                        <th>Tanggal Pembelian</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = mysqli_fetch_assoc($result)): ?>
                        <tr>
                            <td><?php echo $row['judul_buku']; ?></td>
                            <td><?php echo $row['jumlah']; ?></td>
                            <td>Rp <?php echo number_format($row['harga_per_buku'], 0, ',', '.'); ?></td>
                            <td>Rp <?php echo number_format($row['total_harga'], 0, ',', '.'); ?></td>
                            <td><?php echo $row['tanggal_pembelian']; ?></td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p style="text-align:center; color: red;">Anda belum pernah melakukan pembelian.</p>
        <?php endif; ?>

        <a href="perpustakaan.php" class="back-btn">Kembali ke Halaman Pesan</a>
    </div>
</body>
</html>
