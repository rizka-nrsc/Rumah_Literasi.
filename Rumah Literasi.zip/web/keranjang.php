<?php
session_start(); // Mulai session

if (!isset($_SESSION['keranjang']) || count($_SESSION['keranjang']) == 0) {
    echo "<script>window.location.href = 'keranjang_kosong.php';</script>";
    exit;
}

$total_all = 0;
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Keranjang Belanja</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            color: #333;
            margin: 0;
            padding: 0;
        }

        h1 {
            text-align: center;
            color: #007BFF; /* Biru */
            margin-top: 20px;
        }

        .container {
            width: 80%;
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        table th, table td {
            padding: 12px 15px;
            text-align: left;
        }

        table th {
            background-color: #007BFF; /* Biru */
            color: white;
        }

        table td {
            background-color: #f9f9f9;
            border-bottom: 1px solid #ddd;
        }

        table tr:hover {
            background-color: #e9f4fd; /* Biru muda */
        }

        .total-container {
            margin-top: 20px;
            font-size: 1.2em;
            text-align: right;
        }

        .checkout-btn {
            background-color: #007BFF; /* Biru */
            color: white;
            padding: 10px 20px;
            text-align: center;
            text-decoration: none;
            border-radius: 5px;
            display: inline-block;
            margin-top: 20px;
            transition: background-color 0.3s ease;
        }

        .checkout-btn:hover {
            background-color: #0056b3; /* Biru lebih gelap */
        }

        .empty-cart {
            width: 100%;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            background-color: rgba(0, 123, 255, 0.3); /* Biru transparan */
            flex-direction: column;
            animation: fadeIn 2s ease-in-out;
        }

        .empty-cart p {
            font-size: 2em;
            color: #ff3b30;
            animation: fadeIn 2s ease-in-out;
        }

        .back-btn {
            margin-top: 20px;
            background-color: #28a745; /* Hijau */
            color: white;
            padding: 10px 20px;
            text-align: center;
            text-decoration: none;
            border-radius: 5px;
            display: inline-block;
            transition: background-color 0.3s ease;
        }

        .back-btn:hover {
            background-color: #218838; /* Hijau lebih gelap */
        }

        @keyframes fadeIn {
            0% {
                opacity: 0;
                transform: translateY(30px);
            }
            100% {
                opacity: 1;
                transform: translateY(0);
            }
        }
    </style>
</head>
<body>

    <div class="container">
        <h1>Keranjang Belanja</h1>

        <?php if (count($_SESSION['keranjang']) == 0): ?>
            <div class="empty-cart">
                <p>Keranjang Anda kosong. Silakan tambahkan barang ke keranjang!</p>
                <a href="index.php" class="back-btn">Kembali ke Halaman Pesan</a>
            </div>
        <?php else: ?>
            <table>
                <thead>
                    <tr>
                        <th>Judul Buku</th>
                        <th>Jumlah</th>
                        <th>Harga per Buku</th>
                        <th>Total Harga</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($_SESSION['keranjang'] as $item) { 
                        $total_all += $item['total_harga'];
                    ?>
                        <tr>
                            <td><?php echo $item['judul']; ?></td>
                            <td><?php echo $item['jumlah']; ?></td>
                            <td>Rp <?php echo number_format($item['harga'], 0, ',', '.'); ?></td>
                            <td>Rp <?php echo number_format($item['total_harga'], 0, ',', '.'); ?></td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>

            <div class="total-container">
                <h3>Total Belanja: Rp <?php echo number_format($total_all, 0, ',', '.'); ?></h3>
            </div>

            <form action="checkout.php" method="POST">
                <button type="submit" class="checkout-btn">Proses Pembayaran</button>
            </form>
        <?php endif; ?>
    </div>

</body>
</html>
