<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Keranjang Anda Kosong</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f9;
            color: #333;
        }

        .empty-cart {
            width: 100%;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            background-color: rgba(0, 123, 255, 0.3); /* Biru transparan */
            flex-direction: column;
            animation: fadeIn 2s ease-in-out;
        }

        .empty-cart p {
            font-size: 2em;
            color: #ff3b30;
            animation: fadeIn 2s ease-in-out;
        }

        .back-btn {
            margin-top: 20px;
            background-color:rgb(40, 91, 167); /* Hijau */
            color: white;
            padding: 10px 20px;
            text-align: center;
            text-decoration: none;
            border-radius: 5px;
            display: inline-block;
            transition: background-color 0.3s ease;
        }

        .back-btn:hover {
            background-color: #218838; /* Hijau lebih gelap */
        }

        @keyframes fadeIn {
            0% {
                opacity: 0;
                transform: translateY(30px);
            }
            100% {
                opacity: 1;
                transform: translateY(0);
            }
        }
    </style>
</head>
<body>

    <div class="empty-cart">
        <p>Keranjang Anda kosong. Silakan tambahkan barang ke keranjang!</p>
        <a href="perpustakaan.php" class="back-btn">Kembali ke Halaman Pesan</a>

    </div>

</body>
</html>
