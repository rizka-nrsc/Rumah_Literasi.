-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 16, 2025 at 02:03 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rumah literasi`
--

-- --------------------------------------------------------

--
-- Table structure for table `buku`
--

CREATE TABLE `buku` (
  `id` int(11) NOT NULL,
  `judul` varchar(255) NOT NULL,
  `penulis` varchar(255) NOT NULL,
  `harga` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `buku`
--

INSERT INTO `buku` (`id`, `judul`, `penulis`, `harga`) VALUES
(1, 'Statiska dasar untuk ilmu psikologi', 'Baquandi Lutvi Yoseanto', 25000.00),
(2, 'Bicara itu ada seninya', 'OH SU HYANG', 30000.00),
(3, 'Salah Itu Keren', 'Surya alam', 45000.00),
(4, 'Diary Introvert', 'Hardy Zhu', 45000.00),
(5, 'Mencari Teman dan Mempengaruhi Orang Lain', 'Christiana weni', 50000.00),
(6, 'Kau Sedang Terbentuk', 'syahid muhammad', 50000.00),
(7, 'Juara Mengatur Waktu', 'Zivanna Letisha', 25000.00),
(8, 'Sesekali kita butuh sepi', 'ikhsanudin', 30000.00),
(9, 'Banyak yang nggak betah jadi manusia', 'indra sepraneldi', 35000.00),
(10, 'Pendidikan Karakter-Sadar Allah', 'Setiyo Purwanto', 25000.00),
(11, 'Berdamai dengan diri sendiri', 'muthia sayekti', 45000.00),
(12, 'Bumi Manusia', 'pramoedya ananta toer', 30000.00),
(13, 'Membentuk konsep diri melalui budaya', 'Dr Iskandar Zulkarnain, Dr sakhyan Asmara, Raras Sutatminingsih', 30000.00),
(14, 'Setiap Luka akan pulih', 'Halimah', 60000.00),
(15, 'Percaya diri dan harga diri', 'ibrahim elfiky', 55000.00),
(16, 'Cacat Logika', 'dedi mahardi', 75000.00),
(17, 'Manusia Tanpa Sekolah', 'rony k.pratama', 45000.00),
(18, 'Dipersulit oleh pikiran sendiri', '-', 35000.00),
(19, 'Kamu Hanya Perlu Pulang', 'stefany chandra', 60000.00),
(20, 'Quiet', 'susan cain', 75000.00);

-- --------------------------------------------------------

--
-- Table structure for table `transaksi`
--

CREATE TABLE `transaksi` (
  `id` int(11) NOT NULL,
  `id_buku` int(11) DEFAULT NULL,
  `jumlah` int(11) DEFAULT NULL,
  `total_harga` decimal(10,2) DEFAULT NULL,
  `tanggal` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `transaksi`
--

INSERT INTO `transaksi` (`id`, `id_buku`, `jumlah`, `total_harga`, `tanggal`) VALUES
(1, 6, 2, 100000.00, '2025-01-15'),
(2, 6, 2, 100000.00, '2025-01-15'),
(3, 6, 2, 100000.00, '2025-01-15'),
(4, 20, 2, 150000.00, '2025-01-15'),
(5, 6, 2, 100000.00, '2025-01-15'),
(6, 20, 2, 150000.00, '2025-01-15'),
(7, 20, 2, 150000.00, '2025-01-15'),
(8, 20, 2, 150000.00, '2025-01-15'),
(9, 2, 5, 150000.00, '2025-01-15'),
(10, 6, 2, 100000.00, '2025-01-15'),
(11, 2, 5, 150000.00, '2025-01-15'),
(12, 6, 2, 100000.00, '2025-01-15'),
(13, 6, 2, 100000.00, '2025-01-15'),
(14, 6, 2, 100000.00, '2025-01-15'),
(15, 6, 2, 100000.00, '2025-01-15'),
(16, 6, 2, 100000.00, '2025-01-15'),
(17, 6, 2, 100000.00, '2025-01-15'),
(18, 6, 2, 100000.00, '2025-01-15'),
(19, 6, 2, 100000.00, '2025-01-15'),
(20, 6, 2, 100000.00, '2025-01-15'),
(21, 6, 2, 100000.00, '2025-01-15'),
(22, 6, 2, 100000.00, '2025-01-15'),
(23, 6, 2, 100000.00, '2025-01-15'),
(24, 6, 2, 100000.00, '2025-01-15'),
(25, 6, 2, 100000.00, '2025-01-15'),
(26, 6, 2, 100000.00, '2025-01-15'),
(27, 6, 2, 100000.00, '2025-01-15'),
(28, 6, 2, 100000.00, '2025-01-15'),
(29, 6, 2, 100000.00, '2025-01-15'),
(30, 6, 2, 100000.00, '2025-01-15'),
(31, 14, 1, 60.00, '2025-01-15'),
(32, 1, 2, 50000.00, '2025-01-15'),
(33, 1, 2, 50000.00, '2025-01-15'),
(34, 1, 2, 50000.00, '2025-01-15'),
(35, 1, 3, 75000.00, '2025-01-15'),
(36, 14, 2, 120.00, '2025-01-16'),
(37, 15, 1, 55.00, '2025-01-16'),
(38, 13, 6, 180000.00, '2025-01-16');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `buku`
--
ALTER TABLE `buku`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `transaksi`
--
ALTER TABLE `transaksi`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_buku` (`id_buku`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `buku`
--
ALTER TABLE `buku`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `transaksi`
--
ALTER TABLE `transaksi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `transaksi`
--
ALTER TABLE `transaksi`
  ADD CONSTRAINT `transaksi_ibfk_1` FOREIGN KEY (`id_buku`) REFERENCES `buku` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
